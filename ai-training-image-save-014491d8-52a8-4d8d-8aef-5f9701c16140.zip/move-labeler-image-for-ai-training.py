import sys
import boto3
from pymongo import MongoClient
import os
import json
from bson.objectid import ObjectId

MONGO_DB_URL = os.environ.get('mongo_db_url')
mongo_client = MongoClient(MONGO_DB_URL)
core_labeler_assessment_files_db = mongo_client['core']['labeller_assessment_files']
core_assessment_files_db = mongo_client['core']['assessment_files']
bucket_name = os.environ.get('bucket_name')
tmp_path = '/tmp'
aws_key = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')

s3_client = boto3.client('s3',
                         aws_access_key_id=aws_key,
                         aws_secret_access_key=aws_secret_access_key,
                         region_name="us-east-1"
                         )


def train_ai_image_handler(event, context):
    record_list = event["Records"]
    request = record_list[0]['body']
    if isinstance(request, str):
        request = json.loads(request)
    try:
        assessment_id = request["assessmentId"]
        base_path = "training-images/" + assessment_id + "/"
        s3_client.put_object(Bucket=bucket_name, Key=base_path)
        labeler_assessment_files_cursor = core_labeler_assessment_files_db.find({"assessment_id": assessment_id})
        for labeler_file in labeler_assessment_files_cursor:
            labeler_tags = labeler_file['tags']
            labeler_tags_json = json.dumps(labeler_tags)
            assessment_file = core_assessment_files_db.find_one(
                {"_id": ObjectId(labeler_file["orig_assessment_file_id"])})
            if assessment_file is not None:
                file_name_without_ex = os.path.splitext(assessment_file["file_name"])[0]
                json_file_details = tmp_path + "/" + file_name_without_ex + ".json"
                f = open(json_file_details, "a")
                f.write(labeler_tags_json)
                f.close()
                local_image_file_path = tmp_path + "/" + assessment_file["file_name"]
                s3_download_local_image(bucket_name, assessment_file["original_file_path"],
                                        local_image_file_path)
                s3_client.upload_file(local_image_file_path, bucket_name, base_path + assessment_file["file_name"])
                s3_client.upload_file(json_file_details, bucket_name, base_path + file_name_without_ex + ".json")
                for file in [local_image_file_path, json_file_details]:
                    delete_file(file)

        return {
            'statusCode': 200,
            'body': 'SUCCESS'
        }
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        error_log = {"fname":fname,"line_number":str(exc_tb.tb_lineno),"exception_message":str(e)}
        print(str(error_log))
        return {
            'statusCode': 500,
            'body': 'ERROR'
        }


def s3_download_local_image(aws_bucket_name, s3_path, local_file_path):
    s3_client.download_file(aws_bucket_name, s3_path, local_file_path)


def delete_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
    else:
        print("The file does not exist "+file_path)
